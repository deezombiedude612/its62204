import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import com.mad.deezombiedude612.smsinbox.MainActivity;

import static android.content.ContentValues.TAG;

/**
 * Created by deezombiedude612 on 23/11/2017.
 */

public class SmsReceiver extends BroadcastReceiver {
	public static final String SMS_BUNDLE = "pdus";

	@Override
	public void onReceive(Context context, Intent intent) {
		StringBuilder sb = new StringBuilder();
		sb.append("Action: " + intent.getAction() + "\n");
		sb.append("URI: " + intent.toUri(Intent.URI_INTENT_SCHEME).toString() + "\n");
		String log = sb.toString();
		Log.d(TAG, log);
		Toast.makeText(context, log, Toast.LENGTH_LONG).show();

		Bundle intentExtras = intent.getExtras();
		if (intentExtras != null) {
			Object[] sms = (Object[]) intentExtras.get(SMS_BUNDLE);
			String smsMessageStr = "";
			for (int i = 0; i < sms.length; ++i) {
				SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) sms[i]);

				String smsBody = smsMessage.getMessageBody().toString();
				String address = smsMessage.getOriginatingAddress();

				smsMessageStr += "SMS From: " + address + "\n";
				smsMessageStr += smsBody + "\n";
			}
			Toast.makeText(context, smsMessageStr, Toast.LENGTH_SHORT).show();

			//this will update the UI with message
			MainActivity inst = MainActivity.instance();
			inst.updateList(smsMessageStr);
		}
	}
}
