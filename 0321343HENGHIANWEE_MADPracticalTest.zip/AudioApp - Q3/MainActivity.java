package com.mad.deezombiedude612.audioapp;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

	Button btn_start, btn_pause, btn_stop;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		final MediaPlayer puffleMp = MediaPlayer.create(this, R.raw.puffle_shuffle_ringtone);

		btn_start = (Button)findViewById(R.id.btn_start);
		btn_start.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				puffleMp.start();
			}
		});

		btn_pause = (Button)findViewById(R.id.btn_pause);
		btn_pause.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				puffleMp.pause();
			}
		});

		btn_stop = (Button)findViewById(R.id.btn_stop);
		btn_stop.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				puffleMp.stop();
			}
		});
	}
}
